//index.js  
function sendEmail() {
	Email.send({
	Host: "smtp.gmail.com",
	Username : "ibenabidiba@gmail.com",
	Password : "didiba@19971975",
	To : 'walid.ibenabidiba@gmail.gom',
	From : "ibenabidiba@gmail.com",
	Subject : "<email subject>",
	Body : "<email body>",
	}).then(
		message => alert("mail sent successfully")
	);
}